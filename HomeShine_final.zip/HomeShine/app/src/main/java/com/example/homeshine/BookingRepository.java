package com.example.homeshine;

import android.content.Context;
import java.util.List;

public class BookingRepository {

    private static final BookingRepository INSTANCE = new BookingRepository();

    private BookingRepository() {}

    public static BookingRepository getInstance() {
        return INSTANCE;
    }

    public void addBooking(Context context, Booking booking) {
        DatabaseHelper.getInstance(context).addBooking(booking);
    }

    public List<Booking> getBookings(Context context) {
        return DatabaseHelper.getInstance(context).getAllBookings();
    }

    public void deleteBooking(Context context, long id) {
        DatabaseHelper.getInstance(context).deleteBooking(id);
    }
}
