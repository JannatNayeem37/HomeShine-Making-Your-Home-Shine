package com.example.homeshine;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {

    private TextView adminTotalBookings, adminTotalUsers;
    private TextView tabAdminBookings, tabAdminUsers;
    private LinearLayout adminBookingsContainer, adminUsersContainer;
    private TextView adminEmptyBookings, adminEmptyUsers;

    private ListenerRegistration bookingsListener, usersListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        adminTotalBookings = findViewById(R.id.adminTotalBookings);
        adminTotalUsers = findViewById(R.id.adminTotalUsers);

        tabAdminBookings = findViewById(R.id.tabAdminBookings);
        tabAdminUsers = findViewById(R.id.tabAdminUsers);

        adminBookingsContainer = findViewById(R.id.adminBookingsContainer);
        adminUsersContainer = findViewById(R.id.adminUsersContainer);

        adminEmptyBookings = findViewById(R.id.adminEmptyBookings);
        adminEmptyUsers = findViewById(R.id.adminEmptyUsers);

        // Handle both physical Back button and Exit button to return to MainActivity
        OnBackPressedCallback backCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Intent intent = new Intent(AdminDashboardActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, backCallback);

        findViewById(R.id.btnExitAdmin).setOnClickListener(v -> backCallback.handleOnBackPressed());

        tabAdminBookings.setOnClickListener(v -> showBookingsTab());
        tabAdminUsers.setOnClickListener(v -> showUsersTab());

        loadDashboardData();
        setupFirestoreRealtimeListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bookingsListener != null) bookingsListener.remove();
        if (usersListener != null) usersListener.remove();
    }

    private void setupFirestoreRealtimeListeners() {
        // Real-time bookings sync from Firestore
        bookingsListener = FirebaseFirestore.getInstance().collection("bookings")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    List<Booking> cloudBookings = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshots) {
                        String serviceName = doc.getString("serviceName");
                        String emoji = doc.getString("emoji");
                        String when = doc.getString("when");
                        String cleaner = doc.getString("cleaner");
                        String price = doc.getString("price");
                        String address = doc.getString("address");
                        String status = doc.getString("status");

                        if (serviceName != null) {
                            Booking b = new Booking(serviceName, emoji != null ? emoji : "🏠", when, cleaner, price);
                            b.docId = doc.getId();
                            Long idLong = doc.getLong("id");
                            if (idLong != null) {
                                b.id = idLong;
                            } else {
                                try {
                                    b.id = Long.parseLong(doc.getId());
                                } catch (Exception ignored) {}
                            }
                            b.address = address;
                            b.status = status != null ? status : "Confirmed";
                            cloudBookings.add(b);
                        }
                    }
                    if (!cloudBookings.isEmpty()) {
                        renderAdminBookings(cloudBookings);
                        if (adminTotalBookings != null) {
                            adminTotalBookings.setText(String.valueOf(cloudBookings.size()));
                        }
                    }
                });

        // Real-time users sync from Firestore
        usersListener = FirebaseFirestore.getInstance().collection("users")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    List<ContentValues> cloudUsers = new ArrayList<>();
                    for (DocumentSnapshot doc : snapshots) {
                        String name = doc.getString("name");
                        String email = doc.getString("email");
                        Long idLong = doc.getLong("id");

                        if (name != null && email != null) {
                            ContentValues cv = new ContentValues();
                            cv.put("id", idLong != null ? idLong : 0L);
                            cv.put("name", name);
                            cv.put("email", email);
                            cloudUsers.add(cv);
                        }
                    }
                    if (!cloudUsers.isEmpty()) {
                        renderAdminUsers(cloudUsers);
                        if (adminTotalUsers != null) {
                            adminTotalUsers.setText(String.valueOf(cloudUsers.size()));
                        }
                    }
                });
    }

    private void showBookingsTab() {
        tabAdminBookings.setBackgroundResource(R.drawable.bg_tab_active);
        tabAdminBookings.setTextColor(getColor(R.color.teal_dark));

        tabAdminUsers.setBackground(null);
        tabAdminUsers.setTextColor(getColor(R.color.ink_light));

        adminBookingsContainer.setVisibility(View.VISIBLE);
        adminUsersContainer.setVisibility(View.GONE);
    }

    private void showUsersTab() {
        tabAdminUsers.setBackgroundResource(R.drawable.bg_tab_active);
        tabAdminUsers.setTextColor(getColor(R.color.teal_dark));

        tabAdminBookings.setBackground(null);
        tabAdminBookings.setTextColor(getColor(R.color.ink_light));

        adminUsersContainer.setVisibility(View.VISIBLE);
        adminBookingsContainer.setVisibility(View.GONE);
    }

    private void loadDashboardData() {
        ContentValues stats = DatabaseHelper.getInstance(this).getAnalyticsData();
        if (stats != null) {
            Integer totalBookings = stats.getAsInteger("total_bookings");
            Integer totalUsers = stats.getAsInteger("total_users");
            if (adminTotalBookings != null) {
                adminTotalBookings.setText(String.valueOf(totalBookings != null ? totalBookings : 0));
            }
            if (adminTotalUsers != null) {
                adminTotalUsers.setText(String.valueOf(totalUsers != null ? totalUsers : 0));
            }
        }

        loadBookingsList();
        loadUsersList();
    }

    private void loadBookingsList() {
        List<Booking> bookings = DatabaseHelper.getInstance(this).getAllBookings();
        renderAdminBookings(bookings);
    }

    private void renderAdminBookings(List<Booking> bookings) {
        if (adminBookingsContainer == null || adminEmptyBookings == null) return;

        adminBookingsContainer.removeAllViews();
        adminBookingsContainer.addView(adminEmptyBookings);

        if (bookings.isEmpty()) {
            adminEmptyBookings.setVisibility(View.VISIBLE);
        } else {
            adminEmptyBookings.setVisibility(View.GONE);
            LayoutInflater inflater = LayoutInflater.from(this);

            for (Booking b : bookings) {
                View item = inflater.inflate(R.layout.item_booking, adminBookingsContainer, false);
                TextView icon = item.findViewById(R.id.bookingIcon);
                TextView title = item.findViewById(R.id.bookingTitle);
                TextView subtitle = item.findViewById(R.id.bookingSubtitle);
                TextView statusPill = item.findViewById(R.id.bookingStatus);

                if (icon != null) icon.setText(b.emoji != null ? b.emoji : "🏠");
                if (title != null) title.setText(b.serviceName + " (#" + (b.id > 0 ? b.id : b.docId) + ")");
                if (subtitle != null) {
                    String sub = "📅 " + b.when + " · 👤 " + b.cleaner + " (" + b.price + ")";
                    if (!TextUtils.isEmpty(b.address)) sub += "\n📍 " + b.address;
                    subtitle.setText(sub);
                }
                if (statusPill != null) {
                    statusPill.setText(b.status != null ? b.status : "Confirmed");
                    if ("Completed".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_pill_teal);
                        statusPill.setTextColor(Color.WHITE);
                    } else if ("Cancelled".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_input_field);
                        statusPill.setTextColor(Color.RED);
                    } else if ("In Progress".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_pill_lemon);
                        statusPill.setTextColor(Color.BLACK);
                    } else {
                        statusPill.setBackgroundResource(R.drawable.bg_button_purple_light);
                        statusPill.setTextColor(getColor(R.color.purple_dark));
                    }
                }

                item.setOnClickListener(v -> showAdminBookingActions(b));
                adminBookingsContainer.addView(item);
            }
        }
    }

    private void showAdminBookingActions(Booking b) {
        String[] actions = {"Update Status", "Edit Details", "Delete Booking"};

        new AlertDialog.Builder(this)
                .setTitle("Manage Booking #" + (b.id > 0 ? b.id : b.docId))
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) {
                        showUpdateStatusDialog(b);
                    } else if (which == 1) {
                        showEditBookingDetailsDialog(b);
                    } else if (which == 2) {
                        new AlertDialog.Builder(this)
                                .setTitle("Delete Booking?")
                                .setMessage("Permanently remove booking #" + (b.id > 0 ? b.id : b.docId) + " from database?")
                                .setPositiveButton("Delete", (d, w) -> {
                                    if (b.id > 0) {
                                        DatabaseHelper.getInstance(this).deleteBooking(b.id);
                                    }
                                    String targetDocId = (b.docId != null && !b.docId.isEmpty()) ? b.docId : String.valueOf(b.id);
                                    FirebaseFirestore.getInstance().collection("bookings")
                                            .document(targetDocId)
                                            .delete();
                                    Toast.makeText(this, "Booking deleted", Toast.LENGTH_SHORT).show();
                                    loadDashboardData();
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    }
                })
                .show();
    }

    private void showUpdateStatusDialog(Booking b) {
        String[] statuses = {"Confirmed", "In Progress", "Completed", "Cancelled"};

        new AlertDialog.Builder(this)
                .setTitle("Update Status for #" + (b.id > 0 ? b.id : b.docId))
                .setItems(statuses, (dialog, which) -> {
                    String newStatus = statuses[which];
                    b.status = newStatus;
                    if (b.id > 0) {
                        DatabaseHelper.getInstance(this).updateBookingStatus(b.id, newStatus);
                    }

                    String targetDocId = (b.docId != null && !b.docId.isEmpty()) ? b.docId : String.valueOf(b.id);
                    FirebaseFirestore.getInstance().collection("bookings")
                            .document(targetDocId)
                            .update("status", newStatus);

                    Toast.makeText(this, "Status updated to " + newStatus, Toast.LENGTH_SHORT).show();
                    loadDashboardData();
                })
                .show();
    }

    private void showEditBookingDetailsDialog(Booking b) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, pad, pad, 0);

        EditText nameInput = new EditText(this);
        nameInput.setHint("Service Name");
        nameInput.setText(b.serviceName);
        layout.addView(nameInput);

        EditText dateInput = new EditText(this);
        dateInput.setHint("When / Date");
        dateInput.setText(b.when);
        layout.addView(dateInput);

        EditText cleanerInput = new EditText(this);
        cleanerInput.setHint("Assigned Cleaner");
        cleanerInput.setText(b.cleaner);
        layout.addView(cleanerInput);

        EditText priceInput = new EditText(this);
        priceInput.setHint("Price");
        priceInput.setText(b.price);
        layout.addView(priceInput);

        EditText addressInput = new EditText(this);
        addressInput.setHint("Address");
        addressInput.setText(b.address);
        layout.addView(addressInput);

        new AlertDialog.Builder(this)
                .setTitle("Edit Booking #" + (b.id > 0 ? b.id : b.docId))
                .setView(layout)
                .setPositiveButton("Save Changes", (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    String date = dateInput.getText().toString().trim();
                    String cleaner = cleanerInput.getText().toString().trim();
                    String price = priceInput.getText().toString().trim();
                    String address = addressInput.getText().toString().trim();

                    if (b.id > 0) {
                        DatabaseHelper.getInstance(this).updateBookingDetails(
                                b.id, name, date, cleaner, price, address
                        );
                    }

                    Map<String, Object> updates = new HashMap<>();
                    updates.put("serviceName", name);
                    updates.put("when", date);
                    updates.put("cleaner", cleaner);
                    updates.put("price", price);
                    updates.put("address", address);

                    String targetDocId = (b.docId != null && !b.docId.isEmpty()) ? b.docId : String.valueOf(b.id);
                    FirebaseFirestore.getInstance().collection("bookings")
                            .document(targetDocId)
                            .update(updates);

                    Toast.makeText(this, "Booking details updated!", Toast.LENGTH_SHORT).show();
                    loadDashboardData();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadUsersList() {
        List<ContentValues> users = DatabaseHelper.getInstance(this).getAllUsers();
        renderAdminUsers(users);
    }

    private void renderAdminUsers(List<ContentValues> users) {
        if (adminUsersContainer == null || adminEmptyUsers == null) return;

        adminUsersContainer.removeAllViews();
        adminUsersContainer.addView(adminEmptyUsers);

        if (users.isEmpty()) {
            adminEmptyUsers.setVisibility(View.VISIBLE);
        } else {
            adminEmptyUsers.setVisibility(View.GONE);
            for (ContentValues user : users) {
                Long idObj = user.getAsLong("id");
                long userId = idObj != null ? idObj : 0L;
                String nameStr = user.getAsString("name");
                String emailStr = user.getAsString("email");
                final String name = nameStr != null ? nameStr : "User";
                final String email = emailStr != null ? emailStr : "";

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setBackgroundResource(R.drawable.bg_card_stroke);
                int pad = dp(14);
                row.setPadding(pad, pad, pad, pad);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                rowLp.bottomMargin = dp(10);
                row.setLayoutParams(rowLp);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);

                LinearLayout iconBg = new LinearLayout(this);
                iconBg.setBackgroundResource(R.drawable.bg_avatar_circle);
                iconBg.setGravity(android.view.Gravity.CENTER);
                iconBg.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

                TextView icon = new TextView(this);
                icon.setText("👤");
                icon.setTextSize(18);
                iconBg.addView(icon);

                LinearLayout textCol = new LinearLayout(this);
                textCol.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                textLp.leftMargin = dp(12);
                textCol.setLayoutParams(textLp);

                TextView title = new TextView(this);
                title.setText(name + " (ID: #" + userId + ")");
                title.setTextColor(getColor(R.color.ink));
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                title.setTextSize(14);

                TextView subtitle = new TextView(this);
                subtitle.setText(email);
                subtitle.setTextColor(getColor(R.color.gray_text));
                subtitle.setTextSize(12);

                textCol.addView(title);
                textCol.addView(subtitle);

                TextView deleteBtn = new TextView(this);
                deleteBtn.setText("🗑️ Delete");
                deleteBtn.setTextColor(Color.RED);
                deleteBtn.setTextSize(12);
                deleteBtn.setPadding(dp(8), dp(4), dp(8), dp(4));

                row.addView(iconBg);
                row.addView(textCol);
                row.addView(deleteBtn);

                deleteBtn.setOnClickListener(v -> new AlertDialog.Builder(this)
                        .setTitle("Delete User Account?")
                        .setMessage("Are you sure you want to delete user " + name + " (" + email + ")?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            DatabaseHelper.getInstance(this).deleteUser(userId);
                            if (!TextUtils.isEmpty(email)) {
                                FirebaseFirestore.getInstance().collection("users")
                                        .document(email.toLowerCase().trim())
                                        .delete();
                            }
                            Toast.makeText(this, "User deleted", Toast.LENGTH_SHORT).show();
                            loadDashboardData();
                        })
                        .setNegativeButton("Cancel", null)
                        .show());

                adminUsersContainer.addView(row);
            }
        }
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
