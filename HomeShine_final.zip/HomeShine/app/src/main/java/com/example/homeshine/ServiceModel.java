package com.example.homeshine;

import java.io.Serializable;

public class ServiceModel implements Serializable {
    private String name;
    private String category;
    private String description;
    private String price;
    private String emoji;
    private int iconResId;

    public ServiceModel(String name, String price, String emoji) {
        this.name = name;
        this.price = price;
        this.emoji = emoji;
    }

    public ServiceModel(String name, String category, String description, String price, int iconResId) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.price = price;
        this.iconResId = iconResId;
    }

    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getPrice() { return price; }
    public String getEmoji() { return emoji != null ? emoji : "🏠"; }
    public int getIconResId() { return iconResId; }
}
