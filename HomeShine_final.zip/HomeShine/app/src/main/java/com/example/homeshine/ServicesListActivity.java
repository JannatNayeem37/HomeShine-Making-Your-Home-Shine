package com.example.homeshine;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ServicesListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services_list);

        RecyclerView recyclerView = findViewById(R.id.recyclerAllServices);
        if (recyclerView != null) recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<ServiceModel> services = new ArrayList<>();
        services.add(new ServiceModel("Sofa Cleaning", "Home Cleaning", "Deep steam cleaning for sofas and upholstery.", "৳৭৯৯", R.drawable.ic_services));
        services.add(new ServiceModel("Kitchen Deep Clean", "Kitchen", "Degreasing, chimney, and cabinet cleaning.", "৳১,২৯৯", R.drawable.ic_services));
        services.add(new ServiceModel("Bathroom Deep Clean", "Bathroom", "Tile, tap, and drain deep cleaning.", "৳৮৯৯", R.drawable.ic_services));
        services.add(new ServiceModel("AC Servicing", "Appliance", "Gas check, filter clean, cooling check.", "৳৯৯৯", R.drawable.ic_services));

        SearchResultAdapter adapter = new SearchResultAdapter(services, service -> {
            Intent intent = new Intent(ServicesListActivity.this, ServiceDetailActivity.class);
            intent.putExtra("service", service);
            startActivity(intent);
        });
        if (recyclerView != null) recyclerView.setAdapter(adapter);
    }
}
