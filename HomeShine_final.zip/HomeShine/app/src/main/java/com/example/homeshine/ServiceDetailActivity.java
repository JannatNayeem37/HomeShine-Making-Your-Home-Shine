package com.example.homeshine;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ServiceDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_detail);

        ServiceModel service = (ServiceModel) getIntent().getSerializableExtra("service");
        if (service == null) {
            finish();
            return;
        }

        ImageView icon = findViewById(R.id.imgDetailIcon);
        TextView name = findViewById(R.id.textDetailName);
        TextView category = findViewById(R.id.textDetailCategory);
        TextView description = findViewById(R.id.textDetailDescription);
        TextView price = findViewById(R.id.textDetailPrice);

        icon.setImageResource(service.getIconResId());
        name.setText(service.getName());
        category.setText(service.getCategory());
        description.setText(service.getDescription());
        price.setText(service.getPrice());

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        findViewById(R.id.btnBookNow).setOnClickListener(v -> {
            Intent intent = new Intent(ServiceDetailActivity.this, BookingActivity.class);
            intent.putExtra("service", service);
            startActivity(intent);
        });
    }
}
