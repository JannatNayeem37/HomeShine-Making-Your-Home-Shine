package com.example.homeshine;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "homeshine.db";
    private static final int DATABASE_VERSION = 5;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_BOOKINGS = "bookings";
    private static final String TABLE_PAYMENTS = "payment_methods";
    private static final String TABLE_ADDRESSES = "saved_addresses";
    private static final String TABLE_PROFILE = "user_profile";

    private static DatabaseHelper instance;
    private final Context mContext;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.mContext = context != null ? context.getApplicationContext() : null;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "email TEXT UNIQUE, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_BOOKINGS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_email TEXT, " +
                "service_name TEXT, " +
                "emoji TEXT, " +
                "when_time TEXT, " +
                "cleaner TEXT, " +
                "price TEXT, " +
                "address TEXT, " +
                "status TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_PAYMENTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_email TEXT, " +
                "provider TEXT, " +
                "account_number TEXT, " +
                "holder_name TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ADDRESSES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_email TEXT, " +
                "title TEXT, " +
                "address_line TEXT, " +
                "phone TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_PROFILE + " (" +
                "id INTEGER PRIMARY KEY, " +
                "name TEXT, " +
                "email TEXT, " +
                "phone TEXT, " +
                "image_uri TEXT, " +
                "support_phone TEXT, " +
                "support_email TEXT)");

        // Default user
        ContentValues userCv = new ContentValues();
        userCv.put("name", "Jannat Nayeem");
        userCv.put("email", "jannat@homeshine.com");
        userCv.put("password", "123456");
        db.insertWithOnConflict(TABLE_USERS, null, userCv, SQLiteDatabase.CONFLICT_IGNORE);

        // Admin user
        ContentValues adminCv = new ContentValues();
        adminCv.put("name", "System Admin");
        adminCv.put("email", "admin@homeshine.com");
        adminCv.put("password", "admin123");
        db.insertWithOnConflict(TABLE_USERS, null, adminCv, SQLiteDatabase.CONFLICT_IGNORE);

        // Default profile
        ContentValues cv = new ContentValues();
        cv.put("id", 1);
        cv.put("name", "Jannat Nayeem");
        cv.put("email", "jannat@homeshine.com");
        cv.put("phone", "+880 1700-000000");
        cv.put("support_phone", "+880 1800-123456");
        cv.put("support_email", "support@homeshine.com");
        db.insertWithOnConflict(TABLE_PROFILE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PAYMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADDRESSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILE);
        onCreate(db);
    }

    // --- Authentication CRUD ---
    public long registerUser(String name, String email, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("email", email.trim().toLowerCase());
        cv.put("password", password);
        long id = db.insert(TABLE_USERS, null, cv);

        if (id != -1) {
            createOrUpdateUserProfile(name, email, "", "");
        }
        return id;
    }

    public ContentValues authenticateUser(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE LOWER(email)=? AND password=?",
                new String[]{email.trim().toLowerCase(), password});

        ContentValues cv = null;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                cv = new ContentValues();
                cv.put("id", cursor.getLong(cursor.getColumnIndexOrThrow("id")));
                cv.put("name", cursor.getString(cursor.getColumnIndexOrThrow("name")));
                cv.put("email", cursor.getString(cursor.getColumnIndexOrThrow("email")));

                String userEmail = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                String userName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                setActiveUserEmail(userEmail);
                createOrUpdateUserProfile(userName, userEmail, null, null);
            }
            cursor.close();
        }
        return cv;
    }

    public boolean isEmailRegistered(String email) {
        if (email == null || email.trim().isEmpty()) return false;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_USERS + " WHERE LOWER(email)=?",
                new String[]{email.trim().toLowerCase()});
        boolean exists = cursor != null && cursor.moveToFirst();
        if (cursor != null) cursor.close();
        return exists;
    }

    public List<ContentValues> getAllUsers() {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " ORDER BY id DESC", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                ContentValues cv = new ContentValues();
                cv.put("id", cursor.getLong(cursor.getColumnIndexOrThrow("id")));
                cv.put("name", cursor.getString(cursor.getColumnIndexOrThrow("name")));
                cv.put("email", cursor.getString(cursor.getColumnIndexOrThrow("email")));
                list.add(cv);
            }
            cursor.close();
        }
        return list;
    }

    public void deleteUser(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_USERS, "id=?", new String[]{String.valueOf(id)});
    }

    // --- Bookings CRUD ---
    public long addBooking(Booking booking) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_email", getActiveUserEmail());
        cv.put("service_name", booking.serviceName);
        cv.put("emoji", booking.emoji);
        cv.put("when_time", booking.when);
        cv.put("cleaner", booking.cleaner);
        cv.put("price", booking.price);
        cv.put("address", booking.address);
        cv.put("status", booking.status != null ? booking.status : "Confirmed");
        return db.insert(TABLE_BOOKINGS, null, cv);
    }

    public List<Booking> getUserBookings(String email) {
        if (email == null || email.trim().isEmpty()) {
            email = getActiveUserEmail();
        }
        List<Booking> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_BOOKINGS + " WHERE LOWER(user_email)=? ORDER BY id DESC",
                new String[]{email.trim().toLowerCase()});
        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String serviceName = cursor.getString(cursor.getColumnIndexOrThrow("service_name"));
                String emoji = cursor.getString(cursor.getColumnIndexOrThrow("emoji"));
                String when = cursor.getString(cursor.getColumnIndexOrThrow("when_time"));
                String cleaner = cursor.getString(cursor.getColumnIndexOrThrow("cleaner"));
                String price = cursor.getString(cursor.getColumnIndexOrThrow("price"));
                String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));

                Booking b = new Booking(serviceName, emoji, when, cleaner, price);
                b.id = id;
                b.address = address;
                b.status = status;
                list.add(b);
            }
            cursor.close();
        }
        return list;
    }

    public List<Booking> getAllBookings() {
        List<Booking> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_BOOKINGS + " ORDER BY id DESC", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String serviceName = cursor.getString(cursor.getColumnIndexOrThrow("service_name"));
                String emoji = cursor.getString(cursor.getColumnIndexOrThrow("emoji"));
                String when = cursor.getString(cursor.getColumnIndexOrThrow("when_time"));
                String cleaner = cursor.getString(cursor.getColumnIndexOrThrow("cleaner"));
                String price = cursor.getString(cursor.getColumnIndexOrThrow("price"));
                String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));

                Booking b = new Booking(serviceName, emoji, when, cleaner, price);
                b.id = id;
                b.address = address;
                b.status = status;
                list.add(b);
            }
            cursor.close();
        }
        return list;
    }

    public void updateBookingStatus(long id, String status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("status", status);
        db.update(TABLE_BOOKINGS, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public void updateBookingDetails(long id, String serviceName, String when, String cleaner, String price, String address) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        if (serviceName != null) cv.put("service_name", serviceName);
        if (when != null) cv.put("when_time", when);
        if (cleaner != null) cv.put("cleaner", cleaner);
        if (price != null) cv.put("price", price);
        if (address != null) cv.put("address", address);
        db.update(TABLE_BOOKINGS, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteBooking(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_BOOKINGS, "id=?", new String[]{String.valueOf(id)});
    }

    // --- Analytics ---
    public ContentValues getAnalyticsData() {
        ContentValues cv = new ContentValues();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cBookings = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_BOOKINGS, null);
        int totalBookings = 0;
        if (cBookings != null) {
            if (cBookings.moveToFirst()) totalBookings = cBookings.getInt(0);
            cBookings.close();
        }

        Cursor cUsers = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_USERS, null);
        int totalUsers = 0;
        if (cUsers != null) {
            if (cUsers.moveToFirst()) totalUsers = cUsers.getInt(0);
            cUsers.close();
        }

        cv.put("total_bookings", totalBookings);
        cv.put("total_users", totalUsers);

        return cv;
    }

    // --- Payment Methods CRUD ---
    public long addPaymentMethod(String provider, String accountNumber, String holderName) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_email", getActiveUserEmail());
        cv.put("provider", provider);
        cv.put("account_number", accountNumber);
        cv.put("holder_name", holderName);
        return db.insert(TABLE_PAYMENTS, null, cv);
    }

    public List<String> getAllPaymentMethods() {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_PAYMENTS + " ORDER BY id DESC", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String provider = cursor.getString(cursor.getColumnIndexOrThrow("provider"));
                String accountNumber = cursor.getString(cursor.getColumnIndexOrThrow("account_number"));
                list.add(id + "::" + provider + " - " + accountNumber);
            }
            cursor.close();
        }
        return list;
    }

    public void deletePaymentMethod(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_PAYMENTS, "id=?", new String[]{String.valueOf(id)});
    }

    // --- Saved Addresses CRUD ---
    public long addAddress(String title, String addressLine, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_email", getActiveUserEmail());
        cv.put("title", title);
        cv.put("address_line", addressLine);
        cv.put("phone", phone);
        return db.insert(TABLE_ADDRESSES, null, cv);
    }

    public List<String> getAllAddresses() {
        List<String> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ADDRESSES + " ORDER BY id DESC", null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String addressLine = cursor.getString(cursor.getColumnIndexOrThrow("address_line"));
                list.add(id + "::" + title + ": " + addressLine);
            }
            cursor.close();
        }
        return list;
    }

    public void deleteAddress(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_ADDRESSES, "id=?", new String[]{String.valueOf(id)});
    }

    // --- Active Session & Profile CRUD ---
    public void setActiveUserEmail(String email) {
        if (email != null && !email.trim().isEmpty()) {
            String cleanEmail = email.trim().toLowerCase();
            if (mContext != null) {
                mContext.getSharedPreferences("homeshine_session", Context.MODE_PRIVATE)
                        .edit()
                        .putString("active_user_email", cleanEmail)
                        .apply();
            }
        }
    }

    public String getActiveUserEmail() {
        if (mContext != null) {
            String saved = mContext.getSharedPreferences("homeshine_session", Context.MODE_PRIVATE)
                    .getString("active_user_email", "jannat@homeshine.com");
            if (saved != null && !saved.trim().isEmpty()) {
                return saved.trim().toLowerCase();
            }
        }
        return "jannat@homeshine.com";
    }

    public void clearActiveUserSession() {
        if (mContext != null) {
            mContext.getSharedPreferences("homeshine_session", Context.MODE_PRIVATE)
                    .edit()
                    .clear()
                    .apply();
        }
    }

    public void createOrUpdateUserProfile(String name, String email, String phone, String imageUri) {
        if (email == null || email.trim().isEmpty()) return;
        String cleanEmail = email.trim().toLowerCase();

        SQLiteDatabase db = getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_PROFILE + " WHERE LOWER(email)=?", new String[]{cleanEmail});
        boolean exists = cursor != null && cursor.moveToFirst();
        if (cursor != null) cursor.close();

        ContentValues cv = new ContentValues();
        if (name != null && !name.trim().isEmpty()) cv.put("name", name);
        cv.put("email", cleanEmail);
        if (phone != null) cv.put("phone", phone);
        if (imageUri != null) cv.put("image_uri", imageUri);

        if (exists) {
            db.update(TABLE_PROFILE, cv, "LOWER(email)=?", new String[]{cleanEmail});
        } else {
            if (!cv.containsKey("phone")) cv.put("phone", "");
            if (!cv.containsKey("image_uri")) cv.put("image_uri", "");
            cv.put("support_phone", "+880 1800-123456");
            cv.put("support_email", "support@homeshine.com");
            db.insert(TABLE_PROFILE, null, cv);
        }

        setActiveUserEmail(cleanEmail);
    }

    public void updateProfile(String name, String email, String phone) {
        String activeEmail = getActiveUserEmail();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        if (name != null) cv.put("name", name);
        if (email != null) cv.put("email", email.trim().toLowerCase());
        if (phone != null) cv.put("phone", phone);

        db.update(TABLE_PROFILE, cv, "LOWER(email)=?", new String[]{activeEmail});
        if (email != null && !email.trim().isEmpty()) {
            setActiveUserEmail(email);
        }
    }

    public void updateProfileImage(String uri) {
        String activeEmail = getActiveUserEmail();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("image_uri", uri);
        db.update(TABLE_PROFILE, cv, "LOWER(email)=?", new String[]{activeEmail});
    }

    public void updateSupportPhone(String phone) {
        String activeEmail = getActiveUserEmail();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("support_phone", phone);
        db.update(TABLE_PROFILE, cv, "LOWER(email)=?", new String[]{activeEmail});
    }

    public ContentValues getProfile() {
        String activeEmail = getActiveUserEmail();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_PROFILE + " WHERE LOWER(email)=?",
                new String[]{activeEmail});

        ContentValues cv = new ContentValues();
        boolean found = false;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                cv.put("name", cursor.getString(cursor.getColumnIndexOrThrow("name")));
                cv.put("email", cursor.getString(cursor.getColumnIndexOrThrow("email")));
                cv.put("phone", cursor.getString(cursor.getColumnIndexOrThrow("phone")));
                cv.put("image_uri", cursor.getString(cursor.getColumnIndexOrThrow("image_uri")));
                cv.put("support_phone", cursor.getString(cursor.getColumnIndexOrThrow("support_phone")));
                cv.put("support_email", cursor.getString(cursor.getColumnIndexOrThrow("support_email")));
                found = true;
            }
            cursor.close();
        }

        if (!found) {
            Cursor uCursor = db.rawQuery("SELECT name, email FROM " + TABLE_USERS + " WHERE LOWER(email)=?",
                    new String[]{activeEmail});
            String name = "User";
            if (uCursor != null) {
                if (uCursor.moveToFirst()) {
                    name = uCursor.getString(uCursor.getColumnIndexOrThrow("name"));
                }
                uCursor.close();
            }
            cv.put("name", name);
            cv.put("email", activeEmail);
            cv.put("phone", "");
            cv.put("image_uri", "");
            cv.put("support_phone", "+880 1800-123456");
            cv.put("support_email", "support@homeshine.com");
        }

        return cv;
    }
}
