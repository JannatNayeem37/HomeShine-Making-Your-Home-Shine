package com.example.homeshine;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.List;

public class BookingsFragment extends Fragment {

    private LinearLayout container_;
    private TextView emptyState;
    private ListenerRegistration firestoreListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_bookings, container, false);

        container_ = root.findViewById(R.id.bookingsContainer);
        emptyState = root.findViewById(R.id.emptyState);

        loadBookings(inflater);
        setupFirestoreListener();

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getView() != null) {
            LayoutInflater inflater = LayoutInflater.from(requireContext());
            loadBookings(inflater);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (firestoreListener != null) {
            firestoreListener.remove();
            firestoreListener = null;
        }
    }

    private void setupFirestoreListener() {
        String activeEmail = DatabaseHelper.getInstance(requireContext()).getActiveUserEmail();

        firestoreListener = FirebaseFirestore.getInstance()
                .collection("bookings")
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    if (e != null || queryDocumentSnapshots == null) return;
                    if (isAdded() && getView() != null) {
                        List<Booking> cloudBookings = new ArrayList<>();
                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            String userEmail = doc.getString("userEmail");
                            if (userEmail != null && !userEmail.equalsIgnoreCase(activeEmail)) {
                                continue;
                            }

                            String serviceName = doc.getString("serviceName");
                            String emoji = doc.getString("emoji");
                            String when = doc.getString("when");
                            String cleaner = doc.getString("cleaner");
                            String price = doc.getString("price");
                            String address = doc.getString("address");
                            String status = doc.getString("status");

                            if (serviceName != null) {
                                Booking b = new Booking(serviceName, emoji != null ? emoji : "🏠", when, cleaner, price);
                                b.docId = doc.getId();
                                Long idLong = doc.getLong("id");
                                if (idLong != null) {
                                    b.id = idLong;
                                } else {
                                    try {
                                        b.id = Long.parseLong(doc.getId());
                                    } catch (Exception ignored) {}
                                }
                                b.address = address;
                                b.status = status != null ? status : "Confirmed";
                                cloudBookings.add(b);
                            }
                        }
                        renderBookingsList(cloudBookings, LayoutInflater.from(requireContext()));
                    }
                });
    }

    private void loadBookings(LayoutInflater inflater) {
        if (container_ == null || emptyState == null) return;
        String activeEmail = DatabaseHelper.getInstance(requireContext()).getActiveUserEmail();
        List<Booking> bookings = DatabaseHelper.getInstance(requireContext()).getUserBookings(activeEmail);
        renderBookingsList(bookings, inflater);
    }

    private void renderBookingsList(List<Booking> bookings, LayoutInflater inflater) {
        if (container_ == null || emptyState == null) return;

        container_.removeAllViews();
        container_.addView(emptyState);

        if (bookings.isEmpty()) {
            emptyState.setVisibility(View.VISIBLE);
        } else {
            emptyState.setVisibility(View.GONE);
            for (Booking b : bookings) {
                View item = inflater.inflate(R.layout.item_booking, container_, false);
                TextView icon = item.findViewById(R.id.bookingIcon);
                TextView title = item.findViewById(R.id.bookingTitle);
                TextView subtitle = item.findViewById(R.id.bookingSubtitle);
                TextView statusPill = item.findViewById(R.id.bookingStatus);

                if (icon != null) icon.setText(b.emoji);
                if (title != null) title.setText(b.serviceName);
                if (subtitle != null) subtitle.setText(b.when + " · " + b.cleaner + " (" + b.price + ")");
                if (statusPill != null) {
                    statusPill.setText(b.status != null ? b.status : "Confirmed");
                    if ("Completed".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_pill_teal);
                        statusPill.setTextColor(Color.WHITE);
                    } else if ("Cancelled".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_input_field);
                        statusPill.setTextColor(Color.RED);
                    } else if ("In Progress".equalsIgnoreCase(b.status)) {
                        statusPill.setBackgroundResource(R.drawable.bg_pill_lemon);
                        statusPill.setTextColor(Color.BLACK);
                    }
                }

                item.setOnClickListener(v -> new AlertDialog.Builder(requireContext())
                        .setTitle("Cancel Booking?")
                        .setMessage("Are you sure you want to cancel " + b.serviceName + " on " + b.when + "?")
                        .setPositiveButton("Yes, Cancel", (dialog, which) -> {
                            DatabaseHelper.getInstance(requireContext()).deleteBooking(b.id);
                            FirebaseFirestore.getInstance().collection("bookings")
                                    .document(String.valueOf(b.id))
                                    .delete();
                            Toast.makeText(requireContext(), "Booking cancelled", Toast.LENGTH_SHORT).show();
                            loadBookings(inflater);
                        })
                        .setNegativeButton("No", null)
                        .show());

                container_.addView(item, 0);
            }
        }
    }
}
