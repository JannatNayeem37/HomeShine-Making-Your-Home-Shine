package com.example.homeshine;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchResultActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView emptyText;
    private SearchResultAdapter adapter;
    private List<ServiceModel> allServices;
    private List<ServiceModel> filteredServices;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);

        String query = getIntent().getStringExtra("search_query");
        if (query == null) query = "";

        recyclerView = findViewById(R.id.recyclerSearchResults);
        emptyText = findViewById(R.id.textEmptyResults);
        if (recyclerView != null) recyclerView.setLayoutManager(new LinearLayoutManager(this));

        allServices = buildDummyServices();
        filteredServices = filter(query);

        adapter = new SearchResultAdapter(filteredServices, service -> {
            Intent intent = new Intent(SearchResultActivity.this, ServiceDetailActivity.class);
            intent.putExtra("service", service);
            startActivity(intent);
        });
        if (recyclerView != null) recyclerView.setAdapter(adapter);

        if (emptyText != null) {
            emptyText.setVisibility(filteredServices.isEmpty() ? android.view.View.VISIBLE : android.view.View.GONE);
        }

        TextView title = findViewById(R.id.textSearchQuery);
        if (title != null) title.setText("Results for \"" + query + "\"");

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    private List<ServiceModel> filter(String query) {
        List<ServiceModel> result = new ArrayList<>();
        String lower = query.toLowerCase().trim();
        for (ServiceModel s : allServices) {
            if (lower.isEmpty() || s.getName().toLowerCase().contains(lower)
                    || s.getCategory().toLowerCase().contains(lower)) {
                result.add(s);
            }
        }
        return result;
    }

    private List<ServiceModel> buildDummyServices() {
        List<ServiceModel> list = new ArrayList<>();
        list.add(new ServiceModel("Sofa Cleaning", "Home Cleaning", "Deep steam cleaning for sofas and upholstery.", "৳৭৯৯", R.drawable.ic_services));
        list.add(new ServiceModel("Kitchen Deep Clean", "Kitchen", "Degreasing, chimney, and cabinet cleaning.", "৳১,২৯৯", R.drawable.ic_services));
        list.add(new ServiceModel("Bathroom Deep Clean", "Bathroom", "Tile, tap, and drain deep cleaning.", "৳৮৯৯", R.drawable.ic_services));
        list.add(new ServiceModel("AC Servicing", "Appliance", "Gas check, filter clean, cooling check.", "৳৯৯৯", R.drawable.ic_services));
        return list;
    }
}
