package com.example.homeshine;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Safely initialize local database
        try {
            DatabaseHelper.getInstance(this).getWritableDatabase();
        } catch (Exception e) {
            Log.e("HomeShine", "SQLite init error", e);
        }

        // Safely initialize Firestore connection test
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Map<String, Object> testData = new HashMap<>();
            testData.put("app_name", "HomeShine");
            testData.put("status", "Connected Successfully!");

            db.collection("test_connection")
                    .add(testData)
                    .addOnSuccessListener(documentReference ->
                            Log.d("FirebaseTest", "Connected Successfully! ID: " + documentReference.getId()))
                    .addOnFailureListener(e ->
                            Log.w("FirebaseTest", "Connection failed", e));
        } catch (Exception e) {
            Log.e("HomeShine", "Firebase init error", e);
        }

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        // Default tab
        showFragment(new HomeFragment());

        if (bottomNav != null) {
            bottomNav.setOnItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    showFragment(new HomeFragment());
                    return true;
                } else if (id == R.id.nav_bookings) {
                    showFragment(new BookingsFragment());
                    return true;
                } else if (id == R.id.nav_services) {
                    showFragment(new ServicesFragment());
                    return true;
                } else if (id == R.id.nav_profile) {
                    showFragment(new ProfileFragment());
                    return true;
                }
                return false;
            });
        }

        // Smart Back Navigation: If not on Home tab, return to Home tab
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (bottomNav != null && bottomNav.getSelectedItemId() != R.id.nav_home) {
                    bottomNav.setSelectedItemId(R.id.nav_home);
                } else {
                    finish();
                }
            }
        });
    }

    /** Called by HomeFragment's "See all" links to jump to other tabs. */
    public void selectBottomTab(int menuItemId) {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(menuItemId);
        }
    }

    private void showFragment(Fragment fragment) {
        if (isFinishing() || isDestroyed()) return;
        try {
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction tx = fm.beginTransaction();
            tx.replace(R.id.fragmentContainer, fragment);
            tx.commitAllowingStateLoss();
        } catch (Exception e) {
            Log.e("MainActivity", "Error showing fragment", e);
        }
    }
}
