package com.example.homeshine;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder> {

    public interface OnServiceClickListener {
        void onClick(ServiceModel service);
    }

    private final List<ServiceModel> services;
    private final OnServiceClickListener listener;

    public SearchResultAdapter(List<ServiceModel> services, OnServiceClickListener listener) {
        this.services = services;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_search_result, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ServiceModel service = services.get(position);
        holder.icon.setImageResource(service.getIconResId());
        holder.name.setText(service.getName());
        holder.category.setText(service.getCategory());
        holder.price.setText(service.getPrice());
        holder.itemView.setOnClickListener(v -> listener.onClick(service));
    }

    @Override
    public int getItemCount() {
        return services.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView name, category, price;

        ViewHolder(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.imgServiceIcon);
            name = itemView.findViewById(R.id.textServiceName);
            category = itemView.findViewById(R.id.textServiceCategory);
            price = itemView.findViewById(R.id.textServicePrice);
        }
    }
}
