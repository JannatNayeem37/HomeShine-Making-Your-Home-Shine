package com.example.homeshine;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class BookingsActivity extends AppCompatActivity {

    private LinearLayout container_;
    private TextView emptyState;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookings);

        container_ = findViewById(R.id.bookingsContainer);
        emptyState = findViewById(R.id.emptyState);

        loadBookings();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBookings();
    }

    private void loadBookings() {
        if (container_ == null || emptyState == null) return;

        container_.removeAllViews();
        container_.addView(emptyState);

        List<Booking> bookings = DatabaseHelper.getInstance(this).getAllBookings();

        if (bookings.isEmpty()) {
            emptyState.setVisibility(View.VISIBLE);
        } else {
            emptyState.setVisibility(View.GONE);
            LayoutInflater inflater = LayoutInflater.from(this);
            for (Booking b : bookings) {
                View item = inflater.inflate(R.layout.item_booking, container_, false);
                TextView icon = item.findViewById(R.id.bookingIcon);
                TextView title = item.findViewById(R.id.bookingTitle);
                TextView subtitle = item.findViewById(R.id.bookingSubtitle);

                if (icon != null) icon.setText(b.emoji);
                if (title != null) title.setText(b.serviceName);
                if (subtitle != null) subtitle.setText(b.when + " · " + b.cleaner + " (" + b.price + ")");

                item.setOnClickListener(v -> new AlertDialog.Builder(this)
                        .setTitle("Cancel Booking?")
                        .setMessage("Are you sure you want to cancel " + b.serviceName + " on " + b.when + "?")
                        .setPositiveButton("Yes, Cancel", (dialog, which) -> {
                            DatabaseHelper.getInstance(this).deleteBooking(b.id);
                            Toast.makeText(this, "Booking cancelled", Toast.LENGTH_SHORT).show();
                            loadBookings();
                        })
                        .setNegativeButton("No", null)
                        .show());

                container_.addView(item, 0);
            }
        }
    }
}
