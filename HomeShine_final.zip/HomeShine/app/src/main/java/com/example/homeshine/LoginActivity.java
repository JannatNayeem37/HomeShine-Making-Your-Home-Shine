package com.example.homeshine;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private View loginForm, signupForm;
    private TextView tabLogin, tabSignup;
    private TextView roleUserLogin, roleAdminLogin, btnLogin;
    private EditText emailEdit, passwordEdit;

    private boolean isAdminRole = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tabLogin = findViewById(R.id.tabLogin);
        tabSignup = findViewById(R.id.tabSignup);
        loginForm = findViewById(R.id.loginForm);
        signupForm = findViewById(R.id.signupForm);

        roleUserLogin = findViewById(R.id.roleUserLogin);
        roleAdminLogin = findViewById(R.id.roleAdminLogin);
        btnLogin = findViewById(R.id.btnLogin);

        emailEdit = findViewById(R.id.loginPhoneEmail);
        passwordEdit = findViewById(R.id.loginPassword);

        tabLogin.setOnClickListener(v -> showLoginTab());
        tabSignup.setOnClickListener(v -> showSignupTab());

        roleUserLogin.setOnClickListener(v -> selectUserRole());
        roleAdminLogin.setOnClickListener(v -> selectAdminRole());

        btnLogin.setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btnSignup).setOnClickListener(v -> attemptSignup());

        findViewById(R.id.forgotPassword).setOnClickListener(v ->
                Toast.makeText(this, "Password reset link sent to registered email", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnGoogle).setOnClickListener(v ->
                Toast.makeText(this, "Google sign-in coming soon", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnFacebook).setOnClickListener(v ->
                Toast.makeText(this, "Facebook sign-in coming soon", Toast.LENGTH_SHORT).show());
    }

    private void selectUserRole() {
        isAdminRole = false;
        roleUserLogin.setBackgroundResource(R.drawable.bg_pill_lemon);
        roleAdminLogin.setBackgroundResource(R.drawable.bg_card_stroke);
        if (btnLogin != null) btnLogin.setText("Log In");
        if (emailEdit != null) {
            emailEdit.setHint("Phone or Email");
            emailEdit.setText("");
        }
        if (passwordEdit != null) {
            passwordEdit.setHint("Enter your password");
            passwordEdit.setText("");
        }
    }

    private void selectAdminRole() {
        isAdminRole = true;
        roleAdminLogin.setBackgroundResource(R.drawable.bg_pill_lemon);
        roleUserLogin.setBackgroundResource(R.drawable.bg_card_stroke);
        if (btnLogin != null) btnLogin.setText("Log In as Admin");
        if (emailEdit != null) {
            emailEdit.setHint("Admin Email (admin@homeshine.com)");
            emailEdit.setText("");
        }
        if (passwordEdit != null) {
            passwordEdit.setHint("Admin Password");
            passwordEdit.setText("");
        }
    }

    private void showLoginTab() {
        loginForm.setVisibility(View.VISIBLE);
        signupForm.setVisibility(View.GONE);
        tabLogin.setBackgroundResource(R.drawable.bg_tab_active);
        tabSignup.setBackground(null);
        tabLogin.setTextColor(getColor(R.color.teal_dark));
        tabSignup.setTextColor(getColor(R.color.ink_light));
        View roleContainer = findViewById(R.id.roleSelectorContainer);
        if (roleContainer != null) roleContainer.setVisibility(View.VISIBLE);
    }

    private void showSignupTab() {
        loginForm.setVisibility(View.GONE);
        signupForm.setVisibility(View.VISIBLE);
        tabSignup.setBackgroundResource(R.drawable.bg_tab_active);
        tabLogin.setBackground(null);
        tabSignup.setTextColor(getColor(R.color.teal_dark));
        tabLogin.setTextColor(getColor(R.color.ink_light));
        View roleContainer = findViewById(R.id.roleSelectorContainer);
        if (roleContainer != null) roleContainer.setVisibility(View.GONE);
    }

    private void attemptLogin() {
        String email = emailEdit != null ? emailEdit.getText().toString().trim() : "";
        String password = passwordEdit != null ? passwordEdit.getText().toString().trim() : "";

        if (TextUtils.isEmpty(email)) {
            if (emailEdit != null) emailEdit.setError("Enter email");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            if (passwordEdit != null) passwordEdit.setError("Enter password");
            return;
        }

        if (isAdminRole || "admin@homeshine.com".equalsIgnoreCase(email) || "admin".equalsIgnoreCase(email)) {
            if ("admin@homeshine.com".equalsIgnoreCase(email) && "admin123".equals(password)) {
                Toast.makeText(this, "Welcome Admin!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, AdminDashboardActivity.class));
                finish();
                return;
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Access Denied")
                        .setMessage("Invalid Admin Email or Password!\nOnly the single authorized system administrator can log in here.")
                        .setPositiveButton("Try Again", null)
                        .show();
                return;
            }
        }

        ContentValues user = DatabaseHelper.getInstance(this).authenticateUser(email, password);

        if (user != null) {
            String userName = user.getAsString("name");
            Toast.makeText(this, "Welcome back, " + userName + "!", Toast.LENGTH_SHORT).show();
            goHome();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Login Failed")
                    .setMessage("No customer account found with this email and password!\n\nPlease Sign Up first to create an account.")
                    .setPositiveButton("Sign Up Now", (dialog, which) -> showSignupTab())
                    .setNegativeButton("Try Again", null)
                    .show();
        }
    }

    private void attemptSignup() {
        EditText nameEdit = findViewById(R.id.signupName);
        EditText emailEdit = findViewById(R.id.signupPhoneEmail);
        EditText passwordEdit = findViewById(R.id.signupPassword);
        EditText confirmEdit = findViewById(R.id.signupConfirmPassword);

        String name = nameEdit != null ? nameEdit.getText().toString().trim() : "";
        String email = emailEdit != null ? emailEdit.getText().toString().trim() : "";
        String password = passwordEdit != null ? passwordEdit.getText().toString().trim() : "";
        String confirm = confirmEdit != null ? confirmEdit.getText().toString().trim() : "";

        if (TextUtils.isEmpty(name)) {
            if (nameEdit != null) nameEdit.setError("Enter your name");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            if (emailEdit != null) emailEdit.setError("Enter your email");
            return;
        }
        if (email.toLowerCase().contains("admin")) {
            new AlertDialog.Builder(this)
                    .setTitle("Registration Restricted")
                    .setMessage("Admin accounts cannot be created via Sign Up. Only one single system admin is permitted.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            if (passwordEdit != null) passwordEdit.setError("Create a password");
            return;
        }
        if (!password.equals(confirm)) {
            if (confirmEdit != null) confirmEdit.setError("Passwords don't match");
            return;
        }

        long id = DatabaseHelper.getInstance(this).registerUser(name, email, password);

        if (id == -1) {
            Toast.makeText(this, "This email is already registered! Please log in.", Toast.LENGTH_LONG).show();
            showLoginTab();
        } else {
            Toast.makeText(this, "Registration successful! Please log in with your password.", Toast.LENGTH_LONG).show();
            showLoginTab();
        }
    }

    private void goHome() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
