package com.example.homeshine;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class BookingActivity extends AppCompatActivity {

    private String selectedDate = "";
    private String serviceName = "Home Cleaning";
    private String serviceEmoji = "🏠";
    private String servicePrice = "from ৳১,৮০০";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        TextView iconView = findViewById(R.id.bookingSvcIcon);
        TextView nameView = findViewById(R.id.bookingSvcName);
        TextView priceView = findViewById(R.id.bookingSvcPrice);

        EditText nameEdit = findViewById(R.id.bookingName);
        EditText phoneEdit = findViewById(R.id.bookingPhone);
        EditText addressEdit = findViewById(R.id.bookingAddress);
        TextView dateText = findViewById(R.id.bookingDate);
        Button btnBook = findViewById(R.id.btnBook);

        ServiceModel service = (ServiceModel) getIntent().getSerializableExtra("service");
        if (service != null) {
            serviceName = service.getName();
            servicePrice = service.getPrice();
            serviceEmoji = "🏠";
        } else {
            if (getIntent().hasExtra("service_name")) serviceName = getIntent().getStringExtra("service_name");
            if (getIntent().hasExtra("service_emoji")) serviceEmoji = getIntent().getStringExtra("service_emoji");
            if (getIntent().hasExtra("service_price")) servicePrice = getIntent().getStringExtra("service_price");
        }

        if (nameView != null) nameView.setText(serviceName);
        if (priceView != null) priceView.setText(servicePrice);
        if (iconView != null) iconView.setText(serviceEmoji);

        if (dateText != null) {
            dateText.setOnClickListener(v -> {
                Calendar c = Calendar.getInstance();
                DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                        (view, year, month, dayOfMonth) -> {
                            selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                            dateText.setText(selectedDate);
                        },
                        c.get(Calendar.YEAR),
                        c.get(Calendar.MONTH),
                        c.get(Calendar.DAY_OF_MONTH)
                );
                datePickerDialog.show();
            });
        }

        if (btnBook != null) {
            btnBook.setOnClickListener(v -> {
                String name = nameEdit != null ? nameEdit.getText().toString().trim() : "";
                String phone = phoneEdit != null ? phoneEdit.getText().toString().trim() : "";
                String address = addressEdit != null ? addressEdit.getText().toString().trim() : "";

                if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                    Toast.makeText(this, "Please fill in all details", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedDate.isEmpty()) {
                    Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(this, PaymentGatewayActivity.class);
                intent.putExtra("service_name", serviceName);
                intent.putExtra("service_emoji", serviceEmoji);
                intent.putExtra("service_price", servicePrice);
                intent.putExtra("selected_date", selectedDate);
                intent.putExtra("user_address", address);
                startActivity(intent);
            });
        }
    }
}
