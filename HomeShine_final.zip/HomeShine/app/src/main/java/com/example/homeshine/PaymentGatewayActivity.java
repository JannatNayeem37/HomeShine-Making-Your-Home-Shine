package com.example.homeshine;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class PaymentGatewayActivity extends AppCompatActivity {

    private String selectedMethod = "bKash";
    private String serviceName, serviceEmoji, servicePrice, selectedDate, userAddress;

    private TextView payMethodBkash, payMethodNagad, payMethodCard, payMethodCod;
    private Spinner savedMethodSpinner;
    private EditText payAccountNumber, payPin;
    private ProgressBar payProgress;
    private Button btnConfirmPayment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_gateway);

        View btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        serviceName = getIntent().getStringExtra("service_name");
        serviceEmoji = getIntent().getStringExtra("service_emoji");
        servicePrice = getIntent().getStringExtra("service_price");
        selectedDate = getIntent().getStringExtra("selected_date");
        userAddress = getIntent().getStringExtra("user_address");

        if (serviceName == null) serviceName = "Home Cleaning";
        if (serviceEmoji == null) serviceEmoji = "🏠";
        if (servicePrice == null) servicePrice = "৳১,৮০০";
        if (selectedDate == null) selectedDate = "Today";
        if (userAddress == null || userAddress.isEmpty()) userAddress = "Dhanmondi, Dhaka";

        TextView nameView = findViewById(R.id.payServiceName);
        TextView dateView = findViewById(R.id.payDate);
        TextView addressView = findViewById(R.id.payAddress);
        TextView amountView = findViewById(R.id.payTotalAmount);

        if (nameView != null) nameView.setText("Service: " + serviceName);
        if (dateView != null) dateView.setText("Date: " + selectedDate);
        if (addressView != null) addressView.setText("Address: " + userAddress);
        if (amountView != null) amountView.setText("Total Amount: " + servicePrice);

        payMethodBkash = findViewById(R.id.payMethodBkash);
        payMethodNagad = findViewById(R.id.payMethodNagad);
        payMethodCard = findViewById(R.id.payMethodCard);
        payMethodCod = findViewById(R.id.payMethodCod);

        savedMethodSpinner = findViewById(R.id.savedMethodSpinner);
        payAccountNumber = findViewById(R.id.payAccountNumber);
        payPin = findViewById(R.id.payPin);
        payProgress = findViewById(R.id.payProgress);
        btnConfirmPayment = findViewById(R.id.btnConfirmPayment);

        setupMethodSelection();
        loadSavedPaymentMethods();

        btnConfirmPayment.setOnClickListener(v -> processPayment());
    }

    private void loadSavedPaymentMethods() {
        List<String> list = DatabaseHelper.getInstance(this).getAllPaymentMethods();
        if (!list.isEmpty() && savedMethodSpinner != null) {
            List<String> options = new ArrayList<>();
            options.add("-- Select Saved Payment Account --");
            for (String item : list) {
                options.add(item.substring(item.indexOf("::") + 2));
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options);
            savedMethodSpinner.setAdapter(adapter);
            savedMethodSpinner.setVisibility(View.VISIBLE);

            savedMethodSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position > 0) {
                        String selected = options.get(position);
                        if (selected.contains("-")) {
                            String[] parts = selected.split("-");
                            String provider = parts[0].trim();
                            String acc = parts[1].trim();

                            if (provider.equalsIgnoreCase("bKash")) selectMethod("bKash");
                            else if (provider.equalsIgnoreCase("Nagad")) selectMethod("Nagad");
                            else if (provider.toLowerCase().contains("card") || provider.toLowerCase().contains("visa")) selectMethod("Card");

                            if (payAccountNumber != null) {
                                payAccountNumber.setText(acc);
                            }
                        }
                    }
                }
                @Override public void onNothingSelected(AdapterView<?> parent) {}
            });
        }
    }

    private void setupMethodSelection() {
        payMethodBkash.setOnClickListener(v -> selectMethod("bKash"));
        payMethodNagad.setOnClickListener(v -> selectMethod("Nagad"));
        payMethodCard.setOnClickListener(v -> selectMethod("Card"));
        payMethodCod.setOnClickListener(v -> selectMethod("COD"));
    }

    private void selectMethod(String method) {
        selectedMethod = method;

        payMethodBkash.setBackgroundResource(method.equals("bKash") ? R.drawable.bg_pill_lemon : R.drawable.bg_card_stroke);
        payMethodNagad.setBackgroundResource(method.equals("Nagad") ? R.drawable.bg_pill_lemon : R.drawable.bg_card_stroke);
        payMethodCard.setBackgroundResource(method.equals("Card") ? R.drawable.bg_pill_lemon : R.drawable.bg_card_stroke);
        payMethodCod.setBackgroundResource(method.equals("COD") ? R.drawable.bg_pill_lemon : R.drawable.bg_card_stroke);

        if (method.equals("COD")) {
            payAccountNumber.setVisibility(View.GONE);
            payPin.setVisibility(View.GONE);
        } else if (method.equals("Card")) {
            payAccountNumber.setVisibility(View.VISIBLE);
            payPin.setVisibility(View.VISIBLE);
            payAccountNumber.setHint("Enter 16-digit Card Number");
            payPin.setHint("Enter 3-digit CVV");
        } else {
            payAccountNumber.setVisibility(View.VISIBLE);
            payPin.setVisibility(View.VISIBLE);
            payAccountNumber.setHint("Enter " + method + " Mobile Number");
            payPin.setHint("Enter 5-digit PIN");
        }
    }

    private void processPayment() {
        if (!selectedMethod.equals("COD")) {
            String acc = payAccountNumber.getText().toString().trim();
            String pin = payPin.getText().toString().trim();

            if (TextUtils.isEmpty(acc)) {
                payAccountNumber.setError("Account number required!");
                return;
            }
            if (TextUtils.isEmpty(pin)) {
                payPin.setError("PIN/CVV required!");
                return;
            }
        }

        btnConfirmPayment.setEnabled(false);
        payProgress.setVisibility(View.VISIBLE);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            payProgress.setVisibility(View.GONE);
            btnConfirmPayment.setEnabled(true);

            String txnId = "TXN" + (100000 + new Random().nextInt(900000));

            Booking booking = new Booking(serviceName, serviceEmoji, selectedDate, "Assigned Cleaner", servicePrice);
            booking.address = userAddress;
            booking.status = "Confirmed";
            long bookingId = DatabaseHelper.getInstance(this).addBooking(booking);
            String currentUserEmail = DatabaseHelper.getInstance(this).getActiveUserEmail();

            Map<String, Object> firestoreBooking = new HashMap<>();
            firestoreBooking.put("id", bookingId);
            firestoreBooking.put("userEmail", currentUserEmail);
            firestoreBooking.put("serviceName", serviceName);
            firestoreBooking.put("emoji", serviceEmoji);
            firestoreBooking.put("when", selectedDate);
            firestoreBooking.put("cleaner", "Assigned Cleaner");
            firestoreBooking.put("price", servicePrice);
            firestoreBooking.put("address", userAddress);
            firestoreBooking.put("status", "Confirmed");
            firestoreBooking.put("paymentMethod", selectedMethod);
            firestoreBooking.put("txnId", txnId);
            firestoreBooking.put("timestamp", System.currentTimeMillis());

            String docId = bookingId > 0 ? String.valueOf(bookingId) : String.valueOf(System.currentTimeMillis());
            FirebaseFirestore.getInstance().collection("bookings")
                    .document(docId)
                    .set(firestoreBooking);

            new AlertDialog.Builder(this)
                    .setTitle("🎉 Payment Successful!")
                    .setMessage("Payment Method: " + selectedMethod +
                            "\nTxn ID: " + txnId +
                            "\nAmount Paid: " + servicePrice +
                            "\nDelivery Address: " + userAddress +
                            "\n\nYour booking for " + serviceName + " on " + selectedDate + " is confirmed!")
                    .setCancelable(false)
                    .setPositiveButton("Go to My Bookings", (dialog, which) -> {
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .show();
        }, 1500);
    }
}
