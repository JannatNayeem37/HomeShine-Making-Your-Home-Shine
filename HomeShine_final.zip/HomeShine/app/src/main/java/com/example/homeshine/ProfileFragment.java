package com.example.homeshine;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProfileFragment extends Fragment {

    private ImageView profileImage;
    private TextView profileName, profileEmail, profilePhone;
    private ActivityResultLauncher<String> imagePickerLauncher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        try {
                            requireContext().getContentResolver().takePersistableUriPermission(
                                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception ignored) {}
                        DatabaseHelper.getInstance(requireContext()).updateProfileImage(uri.toString());
                        if (profileImage != null) {
                            profileImage.setImageURI(uri);
                        }
                        Toast.makeText(requireContext(), "Profile picture updated", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, container, false);

        profileImage = root.findViewById(R.id.profileImage);
        profileName = root.findViewById(R.id.profileName);
        profileEmail = root.findViewById(R.id.profileEmail);
        profilePhone = root.findViewById(R.id.profilePhone);

        View imgContainer = root.findViewById(R.id.profileImageContainer);
        if (imgContainer != null) {
            imgContainer.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));
        }

        View btnEdit = root.findViewById(R.id.btnEditProfile);
        if (btnEdit != null) btnEdit.setOnClickListener(v -> showEditDialog());

        View rowBookings = root.findViewById(R.id.rowMyBookings);
        if (rowBookings != null) {
            rowBookings.setOnClickListener(v -> {
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).selectBottomTab(R.id.nav_bookings);
                }
            });
        }

        View rowPay = root.findViewById(R.id.rowPayments);
        if (rowPay != null) {
            rowPay.setOnClickListener(v -> showPaymentMethodsDialog());
        }

        View rowAddr = root.findViewById(R.id.rowAddress);
        if (rowAddr != null) {
            rowAddr.setOnClickListener(v -> showSavedAddressesDialog());
        }

        View rowSupport = root.findViewById(R.id.rowSupport);
        if (rowSupport != null) {
            rowSupport.setOnClickListener(v -> showSupportDialog());
        }

        View btnLogout = root.findViewById(R.id.btnLogout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(v ->
                    new AlertDialog.Builder(requireContext())
                            .setTitle("Log out?")
                            .setMessage("You'll need to log in again to book a service.")
                            .setPositiveButton("Log Out", (dialog, which) -> {
                                DatabaseHelper.getInstance(requireContext()).clearActiveUserSession();
                                Intent intent = new Intent(requireContext(), LoginActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            })
                            .setNegativeButton("Cancel", null)
                            .show());
        }

        loadProfileData();

        return root;
    }

    private void loadProfileData() {
        ContentValues cv = DatabaseHelper.getInstance(requireContext()).getProfile();
        if (cv != null) {
            String name = cv.getAsString("name");
            String email = cv.getAsString("email");
            String phone = cv.getAsString("phone");
            String imageUri = cv.getAsString("image_uri");

            if (profileName != null && name != null) profileName.setText(name);
            if (profileEmail != null && email != null) profileEmail.setText(email);
            if (profilePhone != null && phone != null) profilePhone.setText(phone);

            if (profileImage != null && imageUri != null && !imageUri.isEmpty()) {
                try {
                    profileImage.setImageURI(Uri.parse(imageUri));
                } catch (Exception ignored) {}
            }
        }
    }

    private void showEditDialog() {
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, pad, pad, 0);

        EditText nameInput = new EditText(requireContext());
        nameInput.setHint("Full name");
        if (profileName != null) nameInput.setText(profileName.getText());
        layout.addView(nameInput);

        EditText emailInput = new EditText(requireContext());
        emailInput.setHint("Email");
        if (profileEmail != null) emailInput.setText(profileEmail.getText());
        layout.addView(emailInput);

        EditText phoneInput = new EditText(requireContext());
        phoneInput.setHint("Phone number");
        if (profilePhone != null) phoneInput.setText(profilePhone.getText());
        layout.addView(phoneInput);

        new AlertDialog.Builder(requireContext())
                .setTitle("Edit Profile")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    String email = emailInput.getText().toString().trim();
                    String phone = phoneInput.getText().toString().trim();

                    DatabaseHelper.getInstance(requireContext()).updateProfile(name, email, phone);

                    if (!TextUtils.isEmpty(email)) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("name", name);
                        map.put("email", email);
                        map.put("phone", phone);
                        map.put("updated_at", System.currentTimeMillis());

                        FirebaseFirestore.getInstance().collection("user_profiles")
                                .document(email.toLowerCase().trim())
                                .set(map);
                    }

                    loadProfileData();
                    Toast.makeText(requireContext(), "Profile updated & synced", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPaymentMethodsDialog() {
        List<String> list = DatabaseHelper.getInstance(requireContext()).getAllPaymentMethods();

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Payment Methods");

        if (list.isEmpty()) {
            builder.setMessage("No saved payment methods.\nWould you like to add one?");
        } else {
            String[] items = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                String raw = list.get(i);
                items[i] = raw.substring(raw.indexOf("::") + 2);
            }
            builder.setItems(items, (dialog, which) -> {
                String raw = list.get(which);
                long id = Long.parseLong(raw.substring(0, raw.indexOf("::")));
                new AlertDialog.Builder(requireContext())
                        .setTitle("Manage Payment Method")
                        .setMessage(items[which])
                        .setNegativeButton("Delete", (d, w) -> {
                            DatabaseHelper.getInstance(requireContext()).deletePaymentMethod(id);
                            Toast.makeText(requireContext(), "Payment method removed", Toast.LENGTH_SHORT).show();
                        })
                        .setPositiveButton("Close", null)
                        .show();
            });
        }

        builder.setPositiveButton("+ Add Payment Method", (dialog, which) -> showAddPaymentDialog());
        builder.setNegativeButton("Close", null);
        builder.show();
    }

    private void showAddPaymentDialog() {
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, pad, pad, 0);

        Spinner providerSpinner = new Spinner(requireContext());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"bKash", "Nagad", "Rocket", "Visa Card", "MasterCard"});
        providerSpinner.setAdapter(adapter);
        layout.addView(providerSpinner);

        EditText accInput = new EditText(requireContext());
        accInput.setHint("Account or Card Number");
        layout.addView(accInput);

        new AlertDialog.Builder(requireContext())
                .setTitle("Add Payment Method")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String provider = providerSpinner.getSelectedItem().toString();
                    String acc = accInput.getText().toString().trim();
                    if (TextUtils.isEmpty(acc)) {
                        Toast.makeText(requireContext(), "Please enter account or card number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    DatabaseHelper.getInstance(requireContext()).addPaymentMethod(provider, acc, "Account Holder");
                    Toast.makeText(requireContext(), provider + " account saved!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSavedAddressesDialog() {
        List<String> list = DatabaseHelper.getInstance(requireContext()).getAllAddresses();

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Saved Addresses");

        if (list.isEmpty()) {
            builder.setMessage("No saved addresses.\nWould you like to add one?");
        } else {
            String[] items = new String[list.size()];
            for (int i = 0; i < list.size(); i++) {
                String raw = list.get(i);
                items[i] = raw.substring(raw.indexOf("::") + 2);
            }
            builder.setItems(items, (dialog, which) -> {
                String raw = list.get(which);
                long id = Long.parseLong(raw.substring(0, raw.indexOf("::")));
                new AlertDialog.Builder(requireContext())
                        .setTitle("Manage Address")
                        .setMessage(items[which])
                        .setNegativeButton("Delete", (d, w) -> {
                            DatabaseHelper.getInstance(requireContext()).deleteAddress(id);
                            Toast.makeText(requireContext(), "Address deleted", Toast.LENGTH_SHORT).show();
                        })
                        .setPositiveButton("Close", null)
                        .show();
            });
        }

        builder.setPositiveButton("+ Add Address", (dialog, which) -> showAddAddressDialog());
        builder.setNegativeButton("Close", null);
        builder.show();
    }

    private void showAddAddressDialog() {
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, pad, pad, 0);

        EditText titleInput = new EditText(requireContext());
        titleInput.setHint("Title (e.g. Home, Office)");
        layout.addView(titleInput);

        EditText addressInput = new EditText(requireContext());
        addressInput.setHint("Full Address (House, Road, Area)");
        layout.addView(addressInput);

        new AlertDialog.Builder(requireContext())
                .setTitle("Add Saved Address")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String title = titleInput.getText().toString().trim();
                    String addr = addressInput.getText().toString().trim();
                    if (TextUtils.isEmpty(title) || TextUtils.isEmpty(addr)) {
                        Toast.makeText(requireContext(), "Please fill in title and address", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    DatabaseHelper.getInstance(requireContext()).addAddress(title, addr, "");
                    Toast.makeText(requireContext(), "Address saved!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSupportDialog() {
        ContentValues cv = DatabaseHelper.getInstance(requireContext()).getProfile();
        String phone = cv.getAsString("support_phone");
        String email = cv.getAsString("support_email");
        if (phone == null || phone.isEmpty()) phone = "+880 1800-123456";
        if (email == null || email.isEmpty()) email = "support@homeshine.com";

        final String finalPhone = phone;

        new AlertDialog.Builder(requireContext())
                .setTitle("Help & Support")
                .setMessage("Need assistance with your booking?\n\n📞 Support Mobile: " + phone + "\n✉️ Email: " + email)
                .setPositiveButton("Call Support", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + finalPhone));
                    startActivity(intent);
                })
                .setNeutralButton("Edit Support Number", (dialog, which) -> showEditSupportPhoneDialog(finalPhone))
                .setNegativeButton("Close", null)
                .show();
    }

    private void showEditSupportPhoneDialog(String currentPhone) {
        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, pad, pad, 0);

        EditText phoneInput = new EditText(requireContext());
        phoneInput.setHint("Support Mobile Number");
        phoneInput.setText(currentPhone);
        layout.addView(phoneInput);

        new AlertDialog.Builder(requireContext())
                .setTitle("Edit Support Number")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newPhone = phoneInput.getText().toString().trim();
                    if (!TextUtils.isEmpty(newPhone)) {
                        DatabaseHelper.getInstance(requireContext()).updateSupportPhone(newPhone);
                        Toast.makeText(requireContext(), "Support mobile number updated!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
