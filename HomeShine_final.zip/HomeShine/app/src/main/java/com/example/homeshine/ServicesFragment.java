package com.example.homeshine;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServicesFragment extends Fragment {

    private final String[] defaultNames = {
            "Home Cleaning", "Kitchen", "Bathroom", "Deep Cleaning", "Sofa & Carpet",
            "Laundry", "Gardening", "Pest Control", "Painting", "AC Service"
    };
    private final String[] defaultEmojis = {"🏠", "🍳", "🚿", "🧹", "🛋️", "🧺", "🌿", "🐜", "🎨", "❄️"};
    private final String[] defaultPrices = {
            "from ৳১,৮০০", "from ৳১,২০০", "from ৳১,০০০", "from ৳৩,৫০০", "from ৳২,২০০",
            "from ৳৯০০", "from ৳২,০০০", "from ৳২,৫০0", "from ৳৪,০০০", "from ৳৩,০০০"
    };

    private LinearLayout grid;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_services, container, false);
        grid = root.findViewById(R.id.servicesGrid);

        // Render default local list first
        renderServices(getDefaultServiceList());

        // Sync and fetch from Firebase Firestore
        fetchServicesFromFirestore();

        return root;
    }

    private List<ServiceModel> getDefaultServiceList() {
        List<ServiceModel> list = new ArrayList<>();
        for (int i = 0; i < defaultNames.length; i++) {
            list.add(new ServiceModel(defaultNames[i], defaultPrices[i], defaultEmojis[i]));
        }
        return list;
    }

    private void fetchServicesFromFirestore() {
        FirebaseFirestore.getInstance().collection("services")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()) {
                        List<ServiceModel> cloudList = new ArrayList<>();
                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            String name = doc.getString("name");
                            String price = doc.getString("price");
                            String emoji = doc.getString("emoji");

                            if (name != null && price != null) {
                                cloudList.add(new ServiceModel(name, price, emoji != null ? emoji : "🏠"));
                            }
                        }
                        if (!cloudList.isEmpty() && isAdded() && grid != null) {
                            renderServices(cloudList);
                        }
                    } else {
                        // Populate default services to Firestore for future dynamic editing
                        seedDefaultServicesToFirestore();
                    }
                })
                .addOnFailureListener(e -> {
                    // Fail gracefully and keep local rendered list
                });
    }

    private void seedDefaultServicesToFirestore() {
        for (int i = 0; i < defaultNames.length; i++) {
            Map<String, Object> map = new HashMap<>();
            map.put("name", defaultNames[i]);
            map.put("price", defaultPrices[i]);
            map.put("emoji", defaultEmojis[i]);
            map.put("order", i);

            FirebaseFirestore.getInstance().collection("services")
                    .document("service_" + i)
                    .set(map);
        }
    }

    private void renderServices(List<ServiceModel> services) {
        if (grid == null) return;
        grid.removeAllViews();

        for (ServiceModel svc : services) {
            LinearLayout row = new LinearLayout(requireContext());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setBackgroundResource(R.drawable.bg_card_stroke);
            int pad = dp(14);
            row.setPadding(pad, pad, pad, pad);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(10);
            row.setLayoutParams(rowLp);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);

            LinearLayout iconBg = new LinearLayout(requireContext());
            iconBg.setBackgroundResource(R.drawable.bg_icon_sage);
            iconBg.setGravity(android.view.Gravity.CENTER);
            iconBg.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

            TextView icon = new TextView(requireContext());
            icon.setText(svc.getEmoji() != null ? svc.getEmoji() : "🏠");
            icon.setTextSize(20);
            iconBg.addView(icon);

            LinearLayout textCol = new LinearLayout(requireContext());
            textCol.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            textLp.leftMargin = dp(12);
            textCol.setLayoutParams(textLp);

            TextView title = new TextView(requireContext());
            title.setText(svc.getName());
            title.setTextColor(getResources().getColor(R.color.ink));
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setTextSize(14);

            TextView price = new TextView(requireContext());
            price.setText(svc.getPrice());
            price.setTextColor(getResources().getColor(R.color.teal));
            price.setTextSize(12);

            textCol.addView(title);
            textCol.addView(price);

            TextView arrow = new TextView(requireContext());
            arrow.setText("›");
            arrow.setTextSize(18);
            arrow.setTextColor(getResources().getColor(R.color.gray_text));

            row.addView(iconBg);
            row.addView(textCol);
            row.addView(arrow);

            row.setOnClickListener(v -> {
                Intent intent = new Intent(requireContext(), BookingActivity.class);
                intent.putExtra("service_name", svc.getName());
                intent.putExtra("service_emoji", svc.getEmoji());
                intent.putExtra("service_price", svc.getPrice());
                startActivity(intent);
            });

            grid.addView(row);
        }
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
